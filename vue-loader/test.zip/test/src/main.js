import Vue from 'vue';
import App from './app.vue';
import Temp from './temp.vue';

new Vue({
  el: 'body',
  components: {App, Temp}
})