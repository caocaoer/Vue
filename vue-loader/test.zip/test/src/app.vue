<template>
    <div>xxaaa</div>
    <div>{{msg}}</div>
</template>
<script>
    export default{
        data(){
            return {
                msg: 'hello world'
            }
        }
    }
</script>

<style>
    div{
        color: red;
    }
</style>